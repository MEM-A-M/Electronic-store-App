/*
OOP2 Project
Electronic Online Store
Group no.15 - CN
 */

package electronicstore;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.String;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author shaha
 */
public class SecondWindowController implements Initializable {

    @FXML
    private TextField PhoneNumber;
    @FXML
    private Button Cancel;
    @FXML
    private Button Clear;
    @FXML
    private Button Next;
    @FXML
    private ComboBox<String> Country;
    @FXML
    private TextField Email;
    @FXML
    private PasswordField Password;
    @FXML
    private TextField FullName;
    
    private Customer c;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        Country.getItems().addAll(
                " ",
                "Kuwait",
                "Saudi Arabia",
                "Jordan",
                "Bahrain",
                "Qatar",
                "Oman" ,
                "United Arab Emirates" ,
                "Yemen"
        );
    }  

    @FXML
    private void ClearAction(ActionEvent event) {
        
        FullName.setText("");
        Email.setText("");
        PhoneNumber.setText("");
        Password.setText("");
        Country.getSelectionModel().selectFirst();
    }

    @FXML
    private void NextAction(ActionEvent event) throws Exception {
        
      inputValidation();
       c = new Customer(FullName.getText(),PhoneNumber.getText(), Email.getText(),Country.getValue());
       
      writeToFile(c);
      
       try{
           
        ((Node)event.getSource()).getScene().getWindow().hide();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ThirdWindow.fxml"));
        Parent root = loader.load();
           
        ThirdWindowController controller = loader.getController();
        controller.setUserData(FullName.getText(),PhoneNumber.getText(), Email.getText(),
                   Country.getValue());
        
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
       }
       catch (IOException e) {
           e.printStackTrace();
       }
    }
       
   
    private void inputValidation() throws Exception {
        
        if (!validateFirstName()) {
            //only letters
            JOptionPane.showMessageDialog(null, "Invalid Name !", "Error", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
        if (!validateLastName()) {
            //only letters
            JOptionPane.showMessageDialog(null, "Invalid Name !", "Error", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
        if (!validateEmail()) {

            JOptionPane.showMessageDialog(null, "Invalid Email !", "Error", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
        if (!validatePhoneNumber()) {
            //only numbers
            JOptionPane.showMessageDialog(null, "Invalid Phone Number !", "Error", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
        if (!validatePassword()) {
            //only letters
            JOptionPane.showMessageDialog(null, "Weak password !"
                    + " \n You must add letters", "Error", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
        if (Country.getValue() == null || Country.getValue().equals("")) {
            JOptionPane.showMessageDialog(null, "Select Country!", "Error", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
    }
    
    private boolean validateFirstName() {

        return FullName.getText().matches("([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)");
    }

    private boolean validateLastName() {

        return FullName.getText().matches("([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)");

    }

    private boolean validateEmail() {

        return Email.getText().matches("^(.+)@(.+)$");
    }

    private boolean validatePhoneNumber() {

        return PhoneNumber.getText().matches("(05)[0-9]{8}");

    }

    private boolean validatePassword() {
        
        String pattern = "([0-9]{1,})";
        return Password.getText().matches(pattern);
    }
    
    
    
   private void writeToFile(Customer c) {
        
       System.out.println(c);
       
        ObjectOutputStream objectOutputFile = null;
        FileOutputStream outStream = null;
        try {
           System.out.println(c);
            outStream = new FileOutputStream("Customer.txt");
            objectOutputFile = new ObjectOutputStream(outStream);
            
            objectOutputFile.writeObject(c);
            objectOutputFile.close();
            
        } catch (FileNotFoundException ex) {
            System.out.println("Error wrting to file");
        } catch (IOException ex) {
            System.out.println("Error wrting to file");
        }
    }
   
    @FXML
    private void CancelAction(ActionEvent event) {
        
        System.exit(0);
    }
  }