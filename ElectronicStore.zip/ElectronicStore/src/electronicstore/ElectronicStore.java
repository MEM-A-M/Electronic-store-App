/*
OOP2 Project
Electronic Online Store
Group no.15 - CN
 */

package electronicstore;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author shaha
 */
public class ElectronicStore extends Application {
    
    @Override
    public void start(Stage stage) {
        try {
            // Load the FXML file.
            Parent parent = FXMLLoader.load(getClass().getResource("ElectronicStore.fxml"));

            // Build the scene graph.
            Scene scene = new Scene(parent);

            // Display our window, using the scene graph.
            stage.setTitle("Electronic Online Store");
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            System.out.println("FXML Loading Error");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
