/*
OOP2 Project
Electronic Online Store
Group no.15 - CN
 */

package electronicstore;

import java.io.Serializable;

/**
 *
 * @author shaha
 */
public class Customer implements Serializable{
    private String name;
    private String number;
    private String email;
    private String country;

    public Customer(String name, String number, String email, String country) {
        this.name = name;
        this.number = number;
        this.email = email;
        this.country = country;
    }


    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public String getEmail() {
        return email;
    }

    public String getCountry() {
        return country;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "Customer{" + "name=" + name + ", number=" + number + ", email=" + email + ", country=" + country + '}';
    }
    
}
