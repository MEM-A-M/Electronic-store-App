/*
OOP2 Project
Electronic Online Store
Group no.15 - CN
 */

package electronicstore;

import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author shaha
 */
public class FifthWindowController implements Initializable {

    @FXML
    private TextField orderNo;
    @FXML
    private Button finish;
    @FXML
    private Label name;
    @FXML
    private Label number;
    @FXML
    private Label totalPrice;
    @FXML
    private Label email;
    @FXML
    private Label country;
   
    private Customer c;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        Random rnd = new Random();
           int number = rnd.nextInt(999999999); 
           orderNo.setText(String.valueOf(number) + " ");
           
       readFromFile(c);
    } 
   
    public void setUserData(String n, String pn, String e, String coutry,String Price ) {
        
        name.setText(n);
        number.setText(pn);
        email.setText(e);
        country.setText(coutry);
        totalPrice.setText("" + Price );
    }
    
  private void readFromFile(Customer c) {
      
      try{
        InputStream inStream = new FileInputStream("Customer.txt");
          try (ObjectInputStream objectInputFile = new ObjectInputStream(inStream)) {
              c = (Customer) objectInputFile.readObject();
          }
          
        System.out.println(c);
        
        name.setText(c.getName());
        number.setText(c.getNumber());
        email.setText(c.getEmail());
        country.setText(c.getCountry());
      }
      catch (Exception ex) {
            ex.printStackTrace();
        } 
    }
  
    @FXML
    private void finishAction(ActionEvent event) {
        System.exit(0);
    }
    
}
