/*
OOP2 Project
Electronic Online Store
Group no.15 - CN
 */

package electronicstore;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author shaha
 */
public class ThirdWindowController implements Initializable {

    @FXML
    private Button cancel;
    @FXML
    private Button next;
    @FXML
    private ComboBox<String> ipad12;
    @FXML
    private ComboBox<String> iphonePro;
    @FXML
    private ComboBox<String> iphoneProMax;
    @FXML
    private ComboBox<String> ipad11;
    @FXML
    private ComboBox<String> iphone;
    @FXML
    private ComboBox<String> ipad;
    @FXML
    private Label price;
     @FXML
    private Button reset;
     
    private double p;
    
    private String name ;
    
    private String  PhoneNumber ;
    
    private String  Email;
    
    private String Country;
    
    ObservableList<String> iphoneList=FXCollections.observableArrayList
               (" ",
                "iphone13, pink, 128GB",
                "iphone13, pink, 256GB",
                "iphone13, pink, 512GB",
                "iphone13, blue, 128GB",
                "iphone13, blue, 256GB",
                "iphone13, blue, 512GB",
                "iphone13, midnight, 128GB",
                "iphone13, midnight, 256GB",
                "iphone13, midnight, 512GB",
                "iphone13, red, 128GB",
                "iphone13, red, 256GB",
                "iphone13, red, 512GB",
                "iphone13, starlight, 128GB",
                "iphone13, starlight, 256GB",
                "iphone13, starlight, 512GB");
    
    ObservableList<String> iphoneProList=FXCollections.observableArrayList
               (" ",
                "iphone13 pro, sierra blue, 128GB",
                "iphone13 pro, sierra blue, 256GB",
                "iphone13 pro, sierra blue, 512GB",
                "iphone13 pro, silver, 128GB",
                "iphone13 pro, silver, 256GB",
                "iphone13 pro, silver, 512GB",
                "iphone13 pro, gold, 128GB",
                "iphone13 pro, gold, 256GB",
                "iphone13 pro, gold, 512GB",
                "iphone13 pro, graphite, 128GB",
                "iphone13 pro, graphite, 256GB",
                "iphone13 pro, graphite, 512GB");
    
    ObservableList<String> iphoneProMaxList=FXCollections.observableArrayList
               (" ",
                "iphone13 pro max, sierra blue, 128GB",
                "iphone13 pro max, sierra blue, 256GB",
                "iphone13 pro max, sierra blue, 512GB",
                "iphone13 pro max, silver, 128GB",
                "iphone13 pro max, silver, 256GB",
                "iphone13 pro max, silver, 512GB",
                "iphone13 pro max, gold, 128GB",
                "iphone13 pro max, gold, 256GB",
                "iphone13 pro max, gold, 512GB",
                "iphone13 pro max, graphite, 128GB",
                "iphone13 pro max, graphite, 256GB",
                "iphone13 pro max, graphite, 512GB");
    
    ObservableList<String> ipadList=FXCollections.observableArrayList
               (" ",
                "ipad air, rose gold, 64GB",
                "ipad air, rose gold, 256GB",
                "ipad air, sky blue, 64GB",
                "ipad air, sky blue, 256GB",
                "ipad air, silver, 64GB",
                "ipad air, silver, 256GB",
                "ipad air, space gray, 64GB",
                "ipad air, space gray, 256GB",
                "ipad air, green, 64GB",
                "ipad air, green, 256GB");
    
    ObservableList<String> ipad11List=FXCollections.observableArrayList
               (" ",
                "ipad pro 11-inch, space gray, 128GB",
                "ipad pro 11-inch, space gray, 256GB",
                "ipad pro 11-inch, space gray, 512GB",
                "ipad pro 11-inch, silver, 128GB",
                "ipad pro 11-inch, silver, 256GB",
                "ipad pro 11-inch, silver 512GB");
    
    ObservableList<String> ipad12List=FXCollections.observableArrayList
               (" ",
                "ipad pro 12.9-inch, space gray, 128GB",
                "ipad pro 12.9-inch, space gray, 256GB",
                "ipad pro 12.9-inch, space gray, 512GB",
                "ipad pro 12.9-inch, silver, 128GB",
                "ipad pro 12.9-inch, silver, 256GB",
                "ipad pro 12.9-inch, silver 512GB");
   
    
    /**
     * Initializes the controller class.
     */
    
    @Override
     public void initialize(URL url, ResourceBundle rb) {
         
        iphone.valueProperty().addListener(new ChangeListener<String>() {

        public void changed(ObservableValue<? extends String> observable, 
                String oldValue, String newValue) {
            updateLabels(newValue);
        }
    });
          iphone.setItems(iphoneList); 
          
        iphonePro.valueProperty().addListener(new ChangeListener<String>() {

        public void changed(ObservableValue<? extends String> observable2, 
                String oldValue2, String newValue2) {
            updateLabels2(newValue2);
        }
    });
          iphonePro.setItems(iphoneProList); 
          
          iphoneProMax.valueProperty().addListener(new ChangeListener<String>() {

        public void changed(ObservableValue<? extends String> observable3, 
                String oldValue3, String newValue3) {
            updateLabels3(newValue3);
        }
    });
          iphoneProMax.setItems(iphoneProMaxList); 
          
          ipad.valueProperty().addListener(new ChangeListener<String>() {

        public void changed(ObservableValue<? extends String> observable4, 
                String oldValue4, String newValue4) {
            updateLabels4(newValue4);
        }
    });
          ipad.setItems(ipadList);
          
          ipad11.valueProperty().addListener(new ChangeListener<String>() {

        public void changed(ObservableValue<? extends String> observable5, 
                String oldValue5, String newValue5) {
            updateLabels5(newValue5);
        }
    });
          ipad11.setItems(ipad11List);
          
          ipad12.valueProperty().addListener(new ChangeListener<String>() {

        public void changed(ObservableValue<? extends String> observable6, 
                String oldValue6, String newValue6) {
            updateLabels6(newValue6);
        }
    });
          ipad12.setItems(ipad12List);
     }
          
     private void updateLabels(String newValue) {
         
     switch (newValue) {
        case ("iphone13, pink, 128GB"):
            p+=3799;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, pink, 256GB"):
            p+=4299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, pink, 512GB"):
            p+=5299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, blue, 128GB"):
            p+=3799;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, blue, 256GB"):
            p+=4299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, blue, 512GB"):
            p+=5299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, midnight, 128GB"):
            p+=3799;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, midnight, 256GB"):
            p+=4299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, midnight, 512GB"):
            p+=5299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, red, 128GB"):
            p+=3799;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, red, 256GB"):
            p+=4299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, red, 512GB"):
            p+=5299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, starlight, 128GB"):
            p+=3799;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, starlight, 256GB"):
            p+=4299;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13, starlight, 512GB"):
            p+=5299;
            price.setText(String.valueOf(p));
            break;
        default:
            System.out.println("0");
    }
    }
     
private void updateLabels2(String newValue2) {
    switch (newValue2) {
        case ("iphone13 pro, sierra blue, 128GB"):
            p+=4699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, sierra blue, 256GB"):
            p+=5199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, sierra blue, 512GB"):
            p+=6199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, silver, 128GB"):
            p+=4699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, silver, 256GB"):
            p+=5199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, silver, 512GB"):
            p+=6199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, gold, 128GB"):
            p+=4699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, gold, 256GB"):
            p+=5199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, gold, 512GB"):
            p+=6199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, graphite, 128GB"):
            p+=4699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, graphite, 256GB"):
            p+=5199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro, graphite, 512GB"):
            p+=6199;
            price.setText(String.valueOf(p));
            break;
        default:
            System.out.println("0");
    }
    }    

private void updateLabels3(String newValue3) {
    switch (newValue3) {
        case ("iphone13 pro max, sierra blue, 128GB"):
            p+=5199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, sierra blue, 256GB"):
            p+=5699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, sierra blue, 512GB"):
            p+=6699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, silver, 128GB"):
            p+=5199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, silver, 256GB"):
            p+=5699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, silver, 512GB"):
            p+=6699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, gold, 128GB"):
            p+=5199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, gold, 256GB"):
            p+=5699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, gold, 512GB"):
            p+=6699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, graphite, 128GB"):
            p+=5199;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, graphite, 256GB"):
            p+=5699;
            price.setText(String.valueOf(p));
            break;
        case ("iphone13 pro max, graphite, 512GB"):
            p+=6699;
            price.setText(String.valueOf(p));
            break;
        default:
            System.out.println("0");
    }
    }  
private void updateLabels4(String newValue4) {
    switch (newValue4) {
        case ("ipad air, rose gold, 64GB"):
            p+=2799;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, rose gold, 256GB"):
            p+=2499;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, sky blue, 64GB"):
            p+=2799;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, sky blue, 256GB"):
            p+=3499;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, silver, 64GB"):
            p+=2799;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, silver, 256GB"):
            p+=3499;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, space gray, 64GB"):
            price.setText("2799 SR");p+=2799;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, space gray, 256GB"):
            p+=3499;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, green, 64GB"):
            p+=2799;
            price.setText(String.valueOf(p));
            break;
        case ("ipad air, green, 256GB"):
            p+=3499;
            price.setText(String.valueOf(p));
            break;
        default:
            System.out.println("0");
    }
    }
private void updateLabels5(String newValue5) {
    switch (newValue5) {
        case ("ipad pro 11-inch, space gray, 128GB"):
            p+=3499;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 11-inch, space gray, 256GB"):
            p+=4099;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 11-inch, space gray, 512GB"):
            p+=4999;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 11-inch, silver, 128GB"):
            p+=3499;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 11-inch, silver, 256GB"):
            p+=4099;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 11-inch, silver, 512GB"):
            p+=4999;
            price.setText(String.valueOf(p));
            break;
        default:
            System.out.println("0");
    }
    }
private void updateLabels6(String newValue6) {
    switch (newValue6) {
        case ("ipad pro 12.9-inch, space gray, 128GB"):
            p+=4999;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 12.9-inch, space gray, 256GB"):
            p+=5399;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 12.9-inch, space gray, 512GB"):
            p+=5699;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 12.9-inch, silver, 128GB"):
            p+=4999;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 12.9-inch, silver, 256GB"):
            p+=5399;
            price.setText(String.valueOf(p));
            break;
        case ("ipad pro 12.9-inch, silver, 512GB"):
            p+=5699;
            price.setText(String.valueOf(p));
            break;
        default:
            System.out.println("0");
    }
    }

   public void setUserData(String n, String pn, String e, String coutry) {
           
        name = n;
        PhoneNumber = pn;
        Email = e;
        Country = coutry;
   }
   
    @FXML
    private void nextAction(ActionEvent event) {
        
        try {
            ((Node)event.getSource()).getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ForthWindow.fxml"));
            Parent root = loader.load();
            
            FifthWindowController controller4 = loader.getController();
            controller4.setUserData(name, PhoneNumber , Email , Country , price.getText());
              
           Stage stage = new Stage();
           stage.setScene(new Scene(root));
           stage.show();

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    @FXML
    private void resetAction(ActionEvent event) {
        
        iphone.getSelectionModel().selectFirst();
        iphonePro.getSelectionModel().selectFirst();
        iphoneProMax.getSelectionModel().selectFirst();
        ipad.getSelectionModel().selectFirst();
        ipad11.getSelectionModel().selectFirst();
        ipad12.getSelectionModel().selectFirst();
        p=0;
        price.setText("0 SR");
    }
    
    @FXML
    private void cancelAction(ActionEvent event) {
        System.exit(0);
    }
}

